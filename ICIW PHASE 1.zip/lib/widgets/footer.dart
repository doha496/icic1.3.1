// import 'package:flutter/material.dart';
// import 'package:footer/footer.dart';

// class MYFooter extends StatelessWidget {
//   @override
//   Widget build(BuildContext context) {
//     return Footer(Scaffold(
//       bottomNavigationBar: BottomAppBar(
//         child: Text(
//           'ICIW ©2020, All Rights Reserved',
//           textAlign: TextAlign.center,
//           style: TextStyle(
//               fontSize: 15, fontWeight: FontWeight.bold, color: Colors.black),
//         ),
//         color: Color.fromRGBO(124, 67, 75, 1),
//       ),
//     ));
//   }
// }
