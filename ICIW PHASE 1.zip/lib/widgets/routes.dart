// import 'package:iciw_131/screens/add_diary.dart';
// import 'package:iciw_131/screens/chat.dart';
// import 'package:iciw_131/screens/contact_dr.dart';
// import 'package:iciw_131/screens/homepage.dart';
// import 'package:iciw_131/screens/meds.dart';
// import 'package:iciw_131/screens/mood.dart';
// import 'package:iciw_131/screens/mylogs.dart';
// import 'package:iciw_131/screens/quotd.dart';
// import 'package:iciw_131/screens/settings.dart';

// // import 'appdrawer.dart';

// class Routes {
//   static const String home = MYHomepage.routeName;
//   static const String book = MyDiary.routeName;
//   static const String list = Mylogs.routeName;
//   static const String mood = Mymoods.routeName;
//   static const String healing = MyMeds.routeName;
//   static const String bookmark = MyQuotes.routeName;
//   static const String contacts = ContactDr.routeName;
//   static const String chat_bubble = MyChat.routeName;
//   static const String settings = Settings.routeName;
// }
