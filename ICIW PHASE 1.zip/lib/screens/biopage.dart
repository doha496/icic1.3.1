// import 'package:flutter/material.dart';
// import '../widgets/appdrawer.dart';
// import '../providers/user.dart';

// class MyBio extends StatelessWidget {
//   static const routeName = '/biopage';

//   @override
//   Widget build(BuildContext context) {
//     return Scaffold(
//       appBar: AppBar(
//         centerTitle: true,
//         title: Text('ICIW > Profile'),
//         backgroundColor: Color.fromRGBO(124, 67, 75, 1),
//       ),
//       body: Column(
//         children: <Widget>[
//           TextField()
//         ],
//       ),
//       drawer: MyDrawer(),
//       bottomNavigationBar: BottomAppBar(
//         child: Text(
//           'ICIW ©2020, All Rights Reserved',
//           textAlign: TextAlign.center,
//           style: TextStyle(
//               fontSize: 15, fontWeight: FontWeight.bold, color: Colors.black),
//         ),
//         color: Color.fromRGBO(124, 67, 75, 1),
//       ),
//     );
//   }
// }
